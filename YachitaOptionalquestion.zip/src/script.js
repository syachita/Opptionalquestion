//assignment#1
const message = 'Hello world' // Try edit me

// Update header text
document.querySelector('#header').innerHTML = message

// Log to console
console.log(message)

//assignment#2
var mylist=["April", "May", "June"]
console.log(mylist)

//assignment#3
var myList = ["April", "May", "June"];

for (var i = 0; i < myList.length; i++) {
  console.log(myList[i]);
}

//assignment#4
function sumNumbers() {
  var sum = 0;

  for (var i = 1; i <= 100; i++) {
    sum += i;
  }

  return sum;
}

var result = sumNumbers();
console.log(result);